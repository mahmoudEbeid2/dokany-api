import express from "express";
import {
  getCustomerById,
  updateCustomerById,
  deleteCustomerById,
} from "../controllers/customerByIdControllers.js";

import {
  getCustomerByToken_DEBUG,
  getCustomerByToken,
  deleteCustomerByToken,
  updateCustomerByToken,
} from "../controllers/customerControllerToken.js";

import upload from "../utils/multer.js";
import { verifyToken } from "../middlewares/auth.js";

const customerRouter = express.Router();

// Get, Update, Delete by ID (optional if admin)
customerRouter.get("/customers/:id", verifyToken, getCustomerById);
customerRouter.put(
  "/customers/:id",
  upload.single("image"),
  verifyToken,
  updateCustomerById
);
customerRouter.delete("/customers/:id", verifyToken, deleteCustomerById);

// Get, Update, Delete by Token (for customer)
customerRouter.get("/customers/me", verifyToken, getCustomerByToken_DEBUG);
customerRouter.put(
  "/customers/me",
  verifyToken,
  upload.single("image"),
  updateCustomerByToken
);
customerRouter.delete("/customers/me", verifyToken, deleteCustomerByToken);

export default customerRouter;
